# NaivePyDESSEM User Guide

## 1. Introduction

### Purpose and Scope

The **NaivePyDESSEM Project Suite** is a pedagogical framework designed to provide a transparent, modular, and fully reproducible environment for the study and experimentation of **power system operation and expansion planning**. The suite comprises three complementary packages — **NaivePyDESSEM**, **NaivePyDECOMP**, and **MDI** — which collectively simulate, analyze, and optimize short-term dispatch, medium-term operation, and data integration within the energy systems domain.

This User Guide is intended for researchers, graduate students, and professionals seeking to understand the internal logic, structure, and usage of the NaivePyDESSEM ecosystem. The document adopts a formal technical tone consistent with academic and professional documentation standards, offering detailed explanations of modeling principles, solver integration, data preparation, and output interpretation.

### Conceptual Foundations

The NaivePyDESSEM family mirrors the conceptual hierarchy established in the **CEPEL** models — *DESSEM* for short-term operation, *DECOMP* for medium-term optimization, and *NEWAVE* for long-term planning — while maintaining a simplified yet analytically rigorous structure suitable for academic research and classroom experimentation.

Each package is built atop the **Pyomo** optimization framework, leveraging its declarative modeling language to define decision variables, constraints, and objective functions for deterministic and stochastic optimization problems. The design emphasizes clarity of implementation, mathematical transparency, and reproducibility, allowing users to directly inspect, modify, and extend each model component.

### Target Audience

This guide addresses three primary user profiles:

1. **Students and Educators** – who require a didactic framework for demonstrating fundamental principles of energy systems operation and optimization.
2. **Researchers and Developers** – who seek a modular foundation for developing or benchmarking novel optimization methodologies, including stochastic, metaheuristic, or decomposition-based approaches.
3. **Industry Professionals** – who wish to experiment with open, interpretable models before transitioning to large-scale proprietary tools.

### System Requirements

To ensure optimal performance and reproducibility, the following environment is recommended:

* **Operating System:** Linux (preferred), macOS, or Windows 10/11.
* **Python Version:** 3.9 or higher.
* **Required Dependencies:** `pyomo`, `pandas`, `numpy`, `yaml`, `matplotlib`, and `mealpy` (for metaheuristic integration).
* **Optional Solvers:** `GLPK`, `CPLEX`, `Gurobi`, or `IPOPT`.

Installation can be performed via standard Python package management tools:

```bash
pip install naivepydessem
```

### Documentation Conventions

Throughout this guide, the following conventions are used:

* **Monospaced text** denotes command-line inputs or code fragments.
* *Italics* identify technical terms, functions, or variables introduced in the text.
* Boldface (**) is used to highlight crucial terms or key conceptual distinctions.
* Mathematical expressions appear in inline LaTeX syntax when applicable.

Example:

> The **economic dispatch problem** seeks to minimize the total operational cost ( C = \sum_{i} c_i P_i ) subject to power balance and generation limits.

### Versioning and Licensing

All packages within the NaivePyDESSEM ecosystem adhere to **semantic versioning (SemVer)** principles. Updates follow a structured pattern of incremental releases:

* `MAJOR` – structural redesign or interface-breaking changes.
* `MINOR` – feature additions or functional extensions.
* `PATCH` – bug fixes, documentation, or minor corrections.

The project is distributed under the **MIT License**, ensuring unrestricted use, modification, and distribution for educational and research purposes. Users are encouraged to cite the project in academic publications using the official bibliographic entry provided in the *References* section of this guide.

---
## **2. Conceptual Background**

### **2.1 Overview**

The computational modeling of the Brazilian power system is hierarchically structured across three complementary time horizons:  
**long-term**, **medium-term**, and **short-term** operation planning.  
Each layer is represented by a dedicated mathematical optimization model:

- **MDI (Model for Investment Decision)** — long-term expansion and capacity planning;  
- **DECOMP (Short-Term Hydrothermal Operation Model)** — medium-term stochastic operation;  
- **DESSEM (Short-Term Deterministic Scheduling Model)** — short-term deterministic dispatch with hourly resolution.

This multi-horizon architecture ensures that expansion, operation, and real-time dispatch remain economically and energetically consistent.  
The coupling between these models is achieved primarily through the *Future Cost Function (FCF)* and, secondarily, through operational constraints and boundary conditions (reservoir storage, generation targets, and inflow forecasts).

---

### **2.2 MDI – Long-Term Expansion Planning**

The **MDI** model addresses the investment problem in power generation and transmission over a multi-decade horizon.  
It aims to identify the optimal combination of new projects and capacity expansions that minimizes total system cost while ensuring supply adequacy.

The model is formulated as a **Mixed-Integer Linear Programming (MILP)** problem:

\[
\min_{x,g} \; C_\text{inv} + C_\text{op} + C_\text{def}
\]

subject to energy balance and investment feasibility constraints:

\[
\begin{aligned}
& \sum_{s \in S} g_{s,t} + \sum_{i \in G} c_{i,t} \geq D_t, && \forall t \\
& g_{s,t} \leq G_s^{\max} + \sum_{\tau \leq t} \Delta G_{s,\tau} x_{s,\tau}, && \forall s,t \\
& x_{i,t} \in \{0,1\}, \quad g_{s,t} \geq 0
\end{aligned}
\]

where:
- \(x_{i,t}\) — binary variable for investment decision on project \(i\);  
- \(g_{s,t}\) — continuous variable for generation dispatch;  
- \(D_t\) — projected demand;  
- \(\Delta G_{s,\tau}\) — incremental capacity at stage \(\tau\).

The objective function minimizes the sum of **capital (CAPEX)**, **operational (OPEX)**, and **deficit** costs.  
In practical implementations, decomposition methods such as **Benders Decomposition** and **Lagrangian Relaxation** are employed to manage the high dimensionality of the problem.  
Uncertainty in inflows, fuel costs, and demand growth can be handled via **multiscenario stochastic programming**.

The **MDI** thus provides an economically consistent framework for capacity expansion and feeds boundary data to DECOMP in the form of available capacities and system topology.

---

### **2.3 DECOMP – Medium-Term Stochastic Operation**

The **DECOMP** model represents the **medium-term planning problem** of the hydrothermal system, typically with a horizon of up to five years and a monthly or weekly discretization.  
Its main purpose is to determine the optimal energy policy that balances hydro and thermal generation, accounting for hydrological uncertainty.

The model is structured as a **multistage stochastic dynamic programming problem**, expressed through the recursive Bellman equation:

\[
\alpha_t(v_{t-1}) = \min_{g_t, v_t} \Big[ C_T g_t + C_D \text{def}_t + \alpha_{t+1}(v_t) \Big]
\]

subject to the hydric balance constraint:

\[
v_t = v_{t-1} + q_t - (turb_t + vert_t)
\]

where:
- \(v_t\) is the reservoir storage,  
- \(q_t\) the natural inflow,  
- \(turb_t\) the turbined outflow, and  
- \(vert_t\) the spill.

Because the dimensionality grows exponentially with the number of reservoirs (the **curse of dimensionality**), DECOMP employs **Stochastic Dual Dynamic Programming (SDDP)**, also known as **Stochastic Dual Dynamic Decomposition (PDDE)** in the Brazilian literature.  
This approach approximates the *Future Cost Function (FCF)* through a set of linear hyperplanes, known as **Benders cuts**, yielding a piecewise linear convex representation.

At each stage, the **Immediate Cost Function (FCI)**, the **Future Cost Function (FCF)**, and their sum — the **Total Cost Function (FCT)** — are computed as:

\[
\text{FCT}_t = \text{FCI}_t + \text{FCF}_t
\]

The derivative of FCF with respect to the stored volume defines the **water value**, i.e., the marginal cost of using one additional unit of stored water.  
This marginal value directly influences the short-term dispatch in DESSEM through boundary conditions and equivalent future cost terms.

---

### **2.4 DESSEM – Short-Term Deterministic Dispatch**

The **DESSEM** model operates in the **very short term** (up to 7 days, hourly resolution), bridging the planning domain and the real-time dispatch performed by the National System Operator (ONS).  
It determines the economically optimal dispatch of hydro, thermal, and renewable units while enforcing transmission limits and operational security.

Its objective is the minimization of total operational cost:

\[
\min \; C_T g_t + C_S s_t + C_D \text{def}_t
\]

where \(C_T\) are thermal costs, \(C_S\) start-up/shutdown costs, and \(C_D\) deficit penalties.

Unlike DECOMP, DESSEM is **deterministic** and formulated as a **Mixed-Integer Linear Programming (MILP)** problem, incorporating:

- **Continuous variables** for power generation, reservoir volumes, and network flows;  
- **Binary variables** for unit commitment decisions;  
- **DC power flow** constraints for network representation;  
- **Hydraulic continuity** equations ensuring mass conservation.

The model integrates seamlessly with DECOMP by importing:
- reservoir initial states and water values (via FCF);  
- medium-term operation targets;  
- inflow forecasts and demand patterns.

Its outputs — *hourly marginal costs*, *unit schedules*, and *flow limits* — form the initial conditions for real-time operation.

---

### **2.5 The Marginal Cost of Operation (CMO)**

The **Marginal Cost of Operation (CMO)** quantifies the incremental cost of serving one additional megawatt-hour of demand.  
It is obtained from the dual multipliers of the nodal power balance constraints.

Two hierarchical levels of marginal cost are computed:

1. **Nodal Marginal Cost (CMB)** – derived from the shadow price of the power balance at each bus;  
2. **Submarket Marginal Cost (CMO)** – a demand-weighted average of CMBs within each submarket.

The CMO links the mathematical optimization framework to economic decision-making: it guides market price formation (the *short-term price*, or PLD) and reflects the equilibrium between immediate thermal dispatch cost and the water value transmitted from DECOMP.

Formally, at the optimal point:

\[
\frac{\partial \text{FCI}}{\partial V} = - \frac{\partial \text{FCF}}{\partial V}
\]

This equality expresses the balance between current and future costs — the fundamental principle of hydrothermal coordination.

---

### **2.6 Hierarchical Integration of Models**

The three models form a coherent planning chain, ensuring consistency across horizons:

| Horizon | Model | Objective | Methodology | Time Step |
|----------|--------|------------|--------------|------------|
| Long-Term | **MDI** | Expansion planning | MILP / Benders | Annual |
| Medium-Term | **DECOMP** | Stochastic operation | SDDP (PDDE) | Monthly / Weekly |
| Short-Term | **DESSEM** | Deterministic dispatch | MILP | Hourly |

#### **Information Flow**

```
   +----------------+
   |      MDI       |
   | Expansion Plan  |
   +--------+--------+
            |
            v
   +----------------+
   |    DECOMP      |
   | Medium-Term Op. |
   +--------+--------+
            |
            v
   +----------------+
   |    DESSEM      |
   | Short-Term Op.  |
   +----------------+
```

The **NaivePyDESSEM** package reproduces this architecture computationally, enabling reproducible experiments and pedagogical exploration of stochastic–deterministic coupling in hydrothermal optimization.

